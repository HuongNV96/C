#include <iostream>
#include <string>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <fstream>
using namespace std;
//Client side
const int N=2000;

struct yn{
    double value;
    struct yn* next; /*next value*/
    struct yn* prev; /*prev value*/
};
struct yn* yn_list=NULL;	// cac gia tri cua yn duoc luu vao (yn*) yn_list

void addyn(double y){
    struct yn* newyn =(struct yn*) malloc(sizeof(struct yn));
    newyn->value = y;
    if (yn_list == NULL){
        yn_list = newyn;
		yn_list->prev=NULL;
    }
    else{
        struct yn* prev_yn = yn_list;
        newyn->prev = prev_yn;
        prev_yn->next = newyn;
        yn_list = newyn;
    }
}
double* getyn(){
    if (yn_list == NULL){
        return NULL;
    }
    else{
        struct yn* yi = yn_list;
        while(yi->prev){
            yi = yi->prev;
        }
        //yn_list = yi->next;
        if (yi->next){
            yi->next->prev=NULL;
        }
		else
			yn_list=NULL;
        double *result = (double *)malloc(sizeof(double));
		*result=yi->value;
        free(yi);
        return result;
    }
}
int global_var_y=0;
int thread_Y() {
	if(global_var_y>N) {
		return 1;
	}
    static double y = 0;
	y+=1.0/(4*global_var_y-1);
    global_var_y++;
    addyn(y);
	return 0;
}
int count=0;
int main() {
    //we need 2 things: ip address and port number, in that order
	 //grab the IP address and port number 
    char *serverIp = "127.0.0.2"; 
	int port = 8080; 
    //create a message buffer 
    char msg[1500]; 
    //setup a socket and connection tools 
    struct hostent* host = gethostbyname(serverIp); 
    sockaddr_in sendSockAddr;   
    bzero((char*)&sendSockAddr, sizeof(sendSockAddr)); 
    sendSockAddr.sin_family = AF_INET; 
    sendSockAddr.sin_addr.s_addr = 
        inet_addr(inet_ntoa(*(struct in_addr*)*host->h_addr_list));
    sendSockAddr.sin_port = htons(port);
    int clientSd = socket(AF_INET, SOCK_STREAM, 0);
    //try to connect...
    int status = connect(clientSd,
                         (sockaddr*) &sendSockAddr, sizeof(sendSockAddr));
    if(status < 0) {
        	cout<<"Error connecting to socket!"<<endl; 
			return 0;
    }
	//usleep(500);
	while(1) {
    	cout << "Connected to the server!" << endl;
    	int bytesRead, bytesWritten = 0;
        cout << ">";
        string data ="client Y";
		thread_Y();
		if(count>N-1)
			data="exit Y";
        memset(&msg, 0, sizeof(msg));//clear the buffer
        strcpy(msg, data.c_str());
        if(data == "exit Y")
        {
            send(clientSd, (char*)&msg, strlen(msg), 0);
            break;
        }
        bytesWritten += send(clientSd, (char*)&msg, strlen(msg), 0);
        cout << "Awaiting server response..." << endl;
        memset(&msg, 0, sizeof(msg));//clear the buffer
        bytesRead += recv(clientSd, (char*)&msg, sizeof(msg), 0);
		cout << "Server:" <<msg<< endl;
        if(!strcmp(msg, "exit"))
        {
            cout << "Server has quit the session" << endl;
            break;
        }
		if(!strcmp(msg, "rq")) {
			char buffer[20];
			double *result=getyn();
			if(result!=NULL) {
				count++;
				cout<<*result<<endl;
				memset(&msg, 0, sizeof(msg));
				sprintf((char*)msg,"%lf",*result);
				free(result);
			}else {
				memset(&msg, 0, sizeof(msg));
				strcpy((char*)msg,"NODATA");
			}
			bytesWritten += send(clientSd, (char*)&msg, strlen(msg), 0);
			cout << "Awaiting server response..." << endl;
       		memset(&msg, 0, sizeof(msg));//clear the buffer
        	bytesRead += recv(clientSd, (char*)&msg, sizeof(msg), 0);
			cout <<msg<<endl;
		}
		usleep(1000);
    }
	close(clientSd);
    return 0;    
}
