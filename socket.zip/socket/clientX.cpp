#include <iostream>
#include <string>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <fstream>
using namespace std;
//Client side
const int N=2000;

struct xn{
    double value;
    struct xn* next; /*next value*/
    struct xn* prev; /*prev value*/
};
struct xn* xn_list=NULL;	// cac gia tri cua xn duoc luu vao (xn*) xn_list
struct yn* yn_list=NULL;	// nhu tren

void addxn(double x){
    struct xn* newxn =(struct xn*) malloc(sizeof(struct xn));
    newxn->value = x;
    if (xn_list == NULL){
        xn_list = newxn;
		xn_list->prev=NULL;
    }
    else{
        struct xn* prev_xn = xn_list;
        newxn->prev = prev_xn;
        prev_xn->next = newxn;
        xn_list = newxn;
    }
}
double* getxn(){
    if (xn_list == NULL){
        return NULL;
    }
    else{
        struct xn* xi = xn_list;
        while(xi->prev){
            xi = xi->prev;
        }
        //xn_list = xi->next;
        if (xi->next){
            xi->next->prev=NULL;
        }
		else
			xn_list=NULL;
        double *result = (double *)malloc(sizeof(double));
		*result=xi->value;
        free(xi);
        return result;
    }
}
int global_var_x=0;
int thread_X() {
	if(global_var_x>N) {
		return 1;
	}
    static double x = 0;
	x+=1.0/(4*global_var_x+1);
    global_var_x++;
    addxn(x);
	return 0;
}
int count=0;
int main() {
    //we need 2 things: ip address and port number, in that order
	 //grab the IP address and port number 
    char *serverIp = "127.0.0.1"; 
	int port = 8080; 
    //create a message buffer 
    char msg[1500]; 
    //setup a socket and connection tools 
    struct hostent* host = gethostbyname(serverIp); 
    sockaddr_in sendSockAddr;   
    bzero((char*)&sendSockAddr, sizeof(sendSockAddr)); 
    sendSockAddr.sin_family = AF_INET; 
    sendSockAddr.sin_addr.s_addr = 
        inet_addr(inet_ntoa(*(struct in_addr*)*host->h_addr_list));
    sendSockAddr.sin_port = htons(port);
    int clientSd = socket(AF_INET, SOCK_STREAM, 0);
    //try to connect...
    int status = connect(clientSd,
                         (sockaddr*) &sendSockAddr, sizeof(sendSockAddr));
    if(status < 0) {
        	cout<<"Error connecting to socket!"<<endl; 
			return 0;
    }
	while(1) {
    	cout << "Connected to the server!" << endl;
    	int bytesRead, bytesWritten = 0;
        cout << ">";
        string data ="client X";
		thread_X();
		if(count>N-1)
			data="exit X";
        memset(&msg, 0, sizeof(msg));//clear the buffer
        strcpy(msg, data.c_str());
        if(data == "exit X")
        {
            send(clientSd, (char*)&msg, strlen(msg), 0);
            break;
        }
        bytesWritten += send(clientSd, (char*)&msg, strlen(msg), 0);
        cout << "Awaiting server response..." << endl;
        memset(&msg, 0, sizeof(msg));//clear the buffer
        bytesRead += recv(clientSd, (char*)&msg, sizeof(msg), 0);
		cout << "Server:" <<msg<< endl;
        if(!strcmp(msg, "exit"))
        {
            cout << "Server has quit the session" << endl;
            break;
        }
		if(!strcmp(msg, "rq")) {
			char buffer[20];
			double *result=getxn();
			if(result!=NULL) {
				count++;
				cout<<*result<<endl;
				memset(&msg, 0, sizeof(msg));
				sprintf((char*)msg,"%lf",*result);
				free(result);
			}else {
				memset(&msg, 0, sizeof(msg));
				strcpy((char*)msg,"NODATA");
			}
			bytesWritten += send(clientSd, (char*)&msg, strlen(msg), 0);
			cout << "Awaiting server response..." << endl;
       		memset(&msg, 0, sizeof(msg));//clear the buffer
        	bytesRead += recv(clientSd, (char*)&msg, sizeof(msg), 0);
			cout <<msg<<endl;
		}
		usleep(1000);
    }
	close(clientSd);
    return 0;    
}
