#include <iostream>
#include <string>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <fstream>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
using namespace std;
//Server side
int newSd[2]={0,0};
int rq_x=1,rq_y=1;
int stop_X=0,stop_Y=0;
int clientXorY=1;
double xi,yi;
pthread_mutex_t a_mutex;

void* do_threadY (void *vargp) {
	while(1) {
		char msg[1500]; 
		pthread_mutex_lock (&a_mutex);
    	//also keep track of the amount of data sent as well
   		int bytesRead, bytesWritten = 0;
   		string data;
        //receive a message from the client (listen)
        cout << "Awaiting veryfy client response..." << endl;
        memset(&msg, 0, sizeof(msg));//clear the buffer
        bytesRead += recv(newSd[1], (char*)msg, sizeof(msg), 0);
		cout << "Client: " << msg << endl;
        cout << ">";
        if(!strcmp((char*)msg, "exit Y"))
        {
			stop_Y=1;
            cout << "Client has quit the session" << endl;
			pthread_mutex_unlock (&a_mutex);
			break;
        }
		if(!strcmp((char*)msg, "client Y")) {
			clientXorY=0;
			if(rq_y)
				data="rq";
			else
				data="nrq";	
		}
        memset(&msg, 0, sizeof(msg)); //clear the buffer
        strcpy((char*)&msg, data.c_str());
        //send the message to client
        bytesWritten += send(newSd[1], (char*)msg, strlen((char*)msg), 0);
		if(!clientXorY && rq_y) {
			//receive a message from the client (listen)
        	cout << "Awaiting data client response..." << endl;
        	memset(&msg, 0, sizeof(msg));//clear the buffer
        	bytesRead += recv(newSd[1], (char*)msg, sizeof(msg), 0);
			cout << "Client: " << msg << endl;
        	cout << ">";
			if(strcmp((char*)msg, "NODATA")) {
        		sscanf((char*)msg,"%lf",&yi);
				rq_y=0;
			}
			data="OK";
        	memset(&msg, 0, sizeof(msg)); //clear the buffer
        	strcpy((char*)&msg, data.c_str());
			bytesWritten += send(newSd[1], (char*)msg, strlen((char*)msg), 0);
		}
		pthread_mutex_unlock (&a_mutex);
		usleep(1000);
	}
	printf("end Y");
	close(newSd[1]); 
}
void* do_threadX (void *vargp) {
	while(1) {
		char msg[1500]; 
		pthread_mutex_lock (&a_mutex);
    	//also keep track of the amount of data sent as well
   		int bytesRead, bytesWritten = 0;
   		string data;
        //receive a message from the client (listen)
        cout << "Awaiting veryfy client response..." << endl;
        memset(&msg, 0, sizeof(msg));//clear the buffer
        bytesRead += recv(newSd[0], (char*)msg, sizeof(msg), 0);
		cout << "Client: " << msg << endl;
        cout << ">";
        if(!strcmp((char*)msg, "exit X"))
        {
			stop_X=1;
            cout << "Client has quit the session" << endl;
			pthread_mutex_unlock (&a_mutex);
			break;
        }
		if(!strcmp((char*)msg, "client X")) {
			clientXorY=1;
			if(rq_x)
				data="rq";
			else
				data="nrq";	
		}
        memset(&msg, 0, sizeof(msg)); //clear the buffer
        strcpy((char*)&msg, data.c_str());
        //send the message to client
        bytesWritten += send(newSd[0], (char*)msg, strlen((char*)msg), 0);
		if(clientXorY && rq_x) {
			//receive a message from the client (listen)
        	cout << "Awaiting data client response..." << endl;
        	memset(&msg, 0, sizeof(msg));//clear the buffer
        	bytesRead += recv(newSd[0], (char*)msg, sizeof(msg), 0);
			cout << "Client: " << msg << endl;
        	cout << ">";
			if(strcmp((char*)msg, "NODATA")) {
        		sscanf((char*)msg,"%lf",&xi);
				rq_x=0;
			}
			data="OK";
        	memset(&msg, 0, sizeof(msg)); //clear the buffer
        	strcpy((char*)&msg, data.c_str());
			bytesWritten += send(newSd[0], (char*)msg, strlen((char*)msg), 0);
		}
		pthread_mutex_unlock (&a_mutex);
		usleep(1000);
	}
	printf("end X");
	close(newSd[0]); 
}
void* do_threadZ (void *vargp) {
	while(1) {
		pthread_mutex_lock (&a_mutex);
		if((!rq_y) && (!rq_x)) {
			static int index=0;
			printf("z[%d]=%lf \n",index,xi-yi);
			rq_y=1;
			rq_x=1;
			index++;
		}	
		if(stop_X && stop_Y) {
			pthread_mutex_unlock (&a_mutex);
			break;
		}
		pthread_mutex_unlock (&a_mutex);
		usleep(1000);
	}
	printf("end Z");	
}
int main()
{

    //for the server, we only need to specify a port number
	int res=0;
	pthread_t p_thread1;	//Dung de luu thong tin ve luong
    pthread_t p_thread2;	//as above
    pthread_t p_thread3;    //
    //grab the port number
    int port = 8080;
    //buffer to send and receive messages with
     
    //setup a socket and connection tools
    sockaddr_in servAddr;
    bzero((char*)&servAddr, sizeof(servAddr));
    servAddr.sin_family = AF_INET;
    servAddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servAddr.sin_port = htons(port);
 
    //open stream oriented socket with internet address
    //also keep track of the socket descriptor
    int serverSd = socket(AF_INET, SOCK_STREAM, 0);
    if(serverSd < 0)
    {
        cerr << "Error establishing the server socket" << endl;
        exit(0);
    }
    //bind the socket to its local address
    int bindStatus = bind(serverSd, (struct sockaddr*) &servAddr, 
        sizeof(servAddr));
    if(bindStatus < 0)
    {
        cerr << "Error binding socket to local address" << endl;
        exit(0);
    }
    cout << "Waiting for a client to connect..." << endl;
    //listen for up to 5 requests at a time
    listen(serverSd, 10);
    //receive a request from client using accept
    //we need a new address to connect with the client
    sockaddr_in newSockAddr;
    socklen_t newSockAddrSize = sizeof(newSockAddr);
    //accept, create a new socket descriptor to 
    //handle the new connection with client
	res = pthread_mutex_init (&a_mutex, NULL);	//Khoi tao mutex
    if (res != 0){
        printf ("Mutex create error");
        exit (EXIT_FAILURE);
    }
 	while(1) {
		static int count=0;
    	newSd[count] = accept(serverSd, (sockaddr *)&newSockAddr, &newSockAddrSize);
		if (newSd[count]<0)
			return 0;
		cout << "Connected with client!"<<count << endl;
		if (count==1) {
			res = pthread_create (&p_thread1, NULL, &do_threadX, NULL);	//
    		if (res != 0){
        		printf ("Thread create error");
    			exit (EXIT_FAILURE);
    		}
			res = pthread_create (&p_thread2, NULL, &do_threadY, NULL);	//
    		if (res != 0){
        		printf ("Thread create error");
    			exit (EXIT_FAILURE);
    		}
			res = pthread_create (&p_thread3, NULL, &do_threadZ, NULL);	//
    		if (res != 0){
        		printf ("Thread create error");
    			exit (EXIT_FAILURE);
    		}
			//printf("Done");
    		//pthread_join(p_thread1, NULL);
    		//pthread_join(p_thread2, NULL);
   		 	pthread_join(p_thread3, NULL);
			break;
		}	
		count++;
	}
    pthread_mutex_destroy(&a_mutex);
    close(serverSd);  
}
